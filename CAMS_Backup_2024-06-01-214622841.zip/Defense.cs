﻿using Sandbox.ModAPI.Ingame;

namespace IngameScript
{
    public class Defense : CompBase // turrets
    {
        public Defense(string n) : base(n, Lib.u1 | Lib.u10 | Lib.u100)
        {
        }

        #region implementations

        public override void Setup(Program prog)
        {
           
        }

        public override void Update(UpdateFrequency u)
        {
            
        }
        #endregion

    }
}